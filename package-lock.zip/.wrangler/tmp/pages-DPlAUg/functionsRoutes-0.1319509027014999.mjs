import { onRequestPost as __api_books__id__duplicate_js_onRequestPost } from "E:\\palett\\functions\\api\\books\\[id]\\duplicate.js"
import { onRequestDelete as __api_books__id__members_js_onRequestDelete } from "E:\\palett\\functions\\api\\books\\[id]\\members.js"
import { onRequestGet as __api_books__id__members_js_onRequestGet } from "E:\\palett\\functions\\api\\books\\[id]\\members.js"
import { onRequestPost as __api_books__id__members_js_onRequestPost } from "E:\\palett\\functions\\api\\books\\[id]\\members.js"
import { onRequestPost as __api_archive_enter_js_onRequestPost } from "E:\\palett\\functions\\api\\archive\\enter.js"
import { onRequestPost as __api_archive_lock_js_onRequestPost } from "E:\\palett\\functions\\api\\archive\\lock.js"
import { onRequestGet as __api_archive_status_js_onRequestGet } from "E:\\palett\\functions\\api\\archive\\status.js"
import { onRequestPost as __api_archive_verify_js_onRequestPost } from "E:\\palett\\functions\\api\\archive\\verify.js"
import { onRequestPost as __api_auth_login_js_onRequestPost } from "E:\\palett\\functions\\api\\auth\\login.js"
import { onRequestPost as __api_auth_logout_js_onRequestPost } from "E:\\palett\\functions\\api\\auth\\logout.js"
import { onRequestPost as __api_auth_signup_js_onRequestPost } from "E:\\palett\\functions\\api\\auth\\signup.js"
import { onRequestDelete as __api_books__id__index_js_onRequestDelete } from "E:\\palett\\functions\\api\\books\\[id]\\index.js"
import { onRequestGet as __api_books__id__index_js_onRequestGet } from "E:\\palett\\functions\\api\\books\\[id]\\index.js"
import { onRequestPatch as __api_books__id__index_js_onRequestPatch } from "E:\\palett\\functions\\api\\books\\[id]\\index.js"
import { onRequestPut as __api_books__id__index_js_onRequestPut } from "E:\\palett\\functions\\api\\books\\[id]\\index.js"
import { onRequestGet as __api_books_index_js_onRequestGet } from "E:\\palett\\functions\\api\\books\\index.js"
import { onRequestPost as __api_books_index_js_onRequestPost } from "E:\\palett\\functions\\api\\books\\index.js"
import { onRequestDelete as __api_me_js_onRequestDelete } from "E:\\palett\\functions\\api\\me.js"
import { onRequestGet as __api_me_js_onRequestGet } from "E:\\palett\\functions\\api\\me.js"
import { onRequestPatch as __api_me_js_onRequestPatch } from "E:\\palett\\functions\\api\\me.js"
import { onRequest as __api__middleware_js_onRequest } from "E:\\palett\\functions\\api\\_middleware.js"

export const routes = [
    {
      routePath: "/api/books/:id/duplicate",
      mountPath: "/api/books/:id",
      method: "POST",
      middlewares: [],
      modules: [__api_books__id__duplicate_js_onRequestPost],
    },
  {
      routePath: "/api/books/:id/members",
      mountPath: "/api/books/:id",
      method: "DELETE",
      middlewares: [],
      modules: [__api_books__id__members_js_onRequestDelete],
    },
  {
      routePath: "/api/books/:id/members",
      mountPath: "/api/books/:id",
      method: "GET",
      middlewares: [],
      modules: [__api_books__id__members_js_onRequestGet],
    },
  {
      routePath: "/api/books/:id/members",
      mountPath: "/api/books/:id",
      method: "POST",
      middlewares: [],
      modules: [__api_books__id__members_js_onRequestPost],
    },
  {
      routePath: "/api/archive/enter",
      mountPath: "/api/archive",
      method: "POST",
      middlewares: [],
      modules: [__api_archive_enter_js_onRequestPost],
    },
  {
      routePath: "/api/archive/lock",
      mountPath: "/api/archive",
      method: "POST",
      middlewares: [],
      modules: [__api_archive_lock_js_onRequestPost],
    },
  {
      routePath: "/api/archive/status",
      mountPath: "/api/archive",
      method: "GET",
      middlewares: [],
      modules: [__api_archive_status_js_onRequestGet],
    },
  {
      routePath: "/api/archive/verify",
      mountPath: "/api/archive",
      method: "POST",
      middlewares: [],
      modules: [__api_archive_verify_js_onRequestPost],
    },
  {
      routePath: "/api/auth/login",
      mountPath: "/api/auth",
      method: "POST",
      middlewares: [],
      modules: [__api_auth_login_js_onRequestPost],
    },
  {
      routePath: "/api/auth/logout",
      mountPath: "/api/auth",
      method: "POST",
      middlewares: [],
      modules: [__api_auth_logout_js_onRequestPost],
    },
  {
      routePath: "/api/auth/signup",
      mountPath: "/api/auth",
      method: "POST",
      middlewares: [],
      modules: [__api_auth_signup_js_onRequestPost],
    },
  {
      routePath: "/api/books/:id",
      mountPath: "/api/books/:id",
      method: "DELETE",
      middlewares: [],
      modules: [__api_books__id__index_js_onRequestDelete],
    },
  {
      routePath: "/api/books/:id",
      mountPath: "/api/books/:id",
      method: "GET",
      middlewares: [],
      modules: [__api_books__id__index_js_onRequestGet],
    },
  {
      routePath: "/api/books/:id",
      mountPath: "/api/books/:id",
      method: "PATCH",
      middlewares: [],
      modules: [__api_books__id__index_js_onRequestPatch],
    },
  {
      routePath: "/api/books/:id",
      mountPath: "/api/books/:id",
      method: "PUT",
      middlewares: [],
      modules: [__api_books__id__index_js_onRequestPut],
    },
  {
      routePath: "/api/books",
      mountPath: "/api/books",
      method: "GET",
      middlewares: [],
      modules: [__api_books_index_js_onRequestGet],
    },
  {
      routePath: "/api/books",
      mountPath: "/api/books",
      method: "POST",
      middlewares: [],
      modules: [__api_books_index_js_onRequestPost],
    },
  {
      routePath: "/api/me",
      mountPath: "/api",
      method: "DELETE",
      middlewares: [],
      modules: [__api_me_js_onRequestDelete],
    },
  {
      routePath: "/api/me",
      mountPath: "/api",
      method: "GET",
      middlewares: [],
      modules: [__api_me_js_onRequestGet],
    },
  {
      routePath: "/api/me",
      mountPath: "/api",
      method: "PATCH",
      middlewares: [],
      modules: [__api_me_js_onRequestPatch],
    },
  {
      routePath: "/api",
      mountPath: "/api",
      method: "",
      middlewares: [__api__middleware_js_onRequest],
      modules: [],
    },
  ]