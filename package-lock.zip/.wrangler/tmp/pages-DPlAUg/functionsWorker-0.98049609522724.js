var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// ../src/lib/http.js
async function readJson(request, max = 64 * 1024) {
  const len = Number(request.headers.get("content-length")) || 0;
  if (len > max) throw new HttpError(413, "Request too large");
  const text = await request.text();
  if (text.length > max) throw new HttpError(413, "Request too large");
  try {
    return JSON.parse(text);
  } catch {
    throw new HttpError(400, "Invalid JSON");
  }
}
var HttpError, json, clientIp;
var init_http = __esm({
  "../src/lib/http.js"() {
    init_functionsRoutes_0_1319509027014999();
    HttpError = class extends Error {
      static {
        __name(this, "HttpError");
      }
      constructor(status, message) {
        super(message);
        this.status = status;
      }
    };
    json = /* @__PURE__ */ __name((data, status = 200, headers = {}) => new Response(JSON.stringify(data), {
      status,
      headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...headers }
    }), "json");
    __name(readJson, "readJson");
    clientIp = /* @__PURE__ */ __name((request) => request.headers.get("cf-connecting-ip") || "local", "clientIp");
  }
});

// ../src/lib/crypto.js
async function derive(password, salt, iterations) {
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  return crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt, iterations }, key, 256);
}
async function hashPassword(password) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const bits = await derive(password, salt, ITER);
  return `pbkdf2$${ITER}$${toB64(salt)}$${toB64(bits)}`;
}
async function verifyPassword(password, stored) {
  const [scheme, iter, salt, hash2] = String(stored || "").split("$");
  if (scheme !== "pbkdf2") return false;
  const bits = new Uint8Array(await derive(password, fromB64(salt), Number(iter)));
  const want = fromB64(hash2);
  if (bits.length !== want.length) return false;
  let diff = 0;
  for (let i = 0; i < bits.length; i++) diff |= bits[i] ^ want[i];
  return diff === 0;
}
var enc, ITER, toB64, fromB64, toHex, randomToken, sha256Hex, newId, DUMMY_HASH;
var init_crypto = __esm({
  "../src/lib/crypto.js"() {
    init_functionsRoutes_0_1319509027014999();
    enc = new TextEncoder();
    ITER = 1e5;
    toB64 = /* @__PURE__ */ __name((buf) => btoa(String.fromCharCode(...new Uint8Array(buf))), "toB64");
    fromB64 = /* @__PURE__ */ __name((s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0)), "fromB64");
    toHex = /* @__PURE__ */ __name((buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join(""), "toHex");
    __name(derive, "derive");
    __name(hashPassword, "hashPassword");
    __name(verifyPassword, "verifyPassword");
    randomToken = /* @__PURE__ */ __name(() => toHex(crypto.getRandomValues(new Uint8Array(32))), "randomToken");
    sha256Hex = /* @__PURE__ */ __name(async (s) => toHex(await crypto.subtle.digest("SHA-256", enc.encode(s))), "sha256Hex");
    newId = /* @__PURE__ */ __name(() => crypto.randomUUID().replace(/-/g, "").slice(0, 20), "newId");
    DUMMY_HASH = "pbkdf2$100000$AAAAAAAAAAAAAAAAAAAAAA==$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=";
  }
});

// ../src/lib/books.js
async function ownedBook(env, userId, id, unlocked = false) {
  const row = await env.DB.prepare(`SELECT ${META_COLS} FROM books WHERE id = ? AND user_id = ?`).bind(id, userId).first();
  if (!row || row.arch && !unlocked) throw new HttpError(404, "Paintbook not found");
  return row;
}
async function accessibleBook(env, userId, id, unlocked = false) {
  const row = await env.DB.prepare(
    `SELECT ${META_COLS}, user_id FROM books WHERE id = ? AND (user_id = ? OR id IN (SELECT book_id FROM book_members WHERE user_id = ?))`
  ).bind(id, userId, userId).first();
  if (!row || row.arch && row.user_id === userId && !unlocked || row.arch && row.user_id !== userId) throw new HttpError(404, "Paintbook not found");
  return { ...row, isOwner: row.user_id === userId };
}
var CHUNK, MAX_PAYLOAD, MAX_BOOKS, bookMeta, META_COLS, clampDim, chunkStatements, cleanThumb;
var init_books = __esm({
  "../src/lib/books.js"() {
    init_functionsRoutes_0_1319509027014999();
    init_http();
    CHUNK = 6e5;
    MAX_PAYLOAD = 1e7;
    MAX_BOOKS = 500;
    bookMeta = /* @__PURE__ */ __name((r) => ({
      id: r.id,
      name: r.name,
      title: r.title,
      fav: r.fav,
      arch: r.arch,
      w: r.w,
      h: r.h,
      scroll: r.scroll,
      thumb: r.thumb,
      created: r.created_at,
      updated: r.updated_at,
      shared: r.shared ? 1 : 0
    }), "bookMeta");
    META_COLS = "id, name, title, fav, arch, w, h, scroll, thumb, created_at, updated_at";
    clampDim = /* @__PURE__ */ __name((v) => Math.min(8e3, Math.max(64, Math.round(Number(v)) || 64)), "clampDim");
    chunkStatements = /* @__PURE__ */ __name((env, bookId, text) => {
      const out = [];
      for (let i = 0, n = 0; i < text.length || n === 0; i += CHUNK, n++) {
        out.push(env.DB.prepare("INSERT INTO book_chunks (book_id, idx, data) VALUES (?, ?, ?)").bind(bookId, n, text.slice(i, i + CHUNK)));
      }
      return out;
    }, "chunkStatements");
    __name(ownedBook, "ownedBook");
    cleanThumb = /* @__PURE__ */ __name((t) => typeof t === "string" && t.startsWith("data:image/jpeg;base64,") && t.length < 25e4 ? t : "", "cleanThumb");
    __name(accessibleBook, "accessibleBook");
  }
});

// api/books/[id]/duplicate.js
async function onRequestPost({ env, data, params }) {
  const src = await ownedBook(env, data.user.id, params.id, data.unlocked);
  const count = await env.DB.prepare("SELECT COUNT(*) AS n FROM books WHERE user_id = ?").bind(data.user.id).first();
  if (count.n >= MAX_BOOKS) throw new HttpError(403, `Limit of ${MAX_BOOKS} paintbooks reached.`);
  const id = newId(), now = Date.now(), name = `${src.name} copy`.slice(0, 60);
  await env.DB.batch([
    env.DB.prepare(
      `INSERT INTO books (id, user_id, name, title, fav, arch, w, h, scroll, thumb, size, created_at, updated_at)
       SELECT ?, user_id, ?, title, 0, arch, w, h, scroll, thumb, size, ?, ? FROM books WHERE id = ? AND user_id = ?`
    ).bind(id, name, now, now, src.id, data.user.id),
    env.DB.prepare("INSERT INTO book_chunks (book_id, idx, data) SELECT ?, idx, data FROM book_chunks WHERE book_id = ?").bind(id, src.id)
  ]);
  return json({ book: bookMeta({ ...src, id, name, fav: 0, created_at: now, updated_at: now }) }, 201);
}
var init_duplicate = __esm({
  "api/books/[id]/duplicate.js"() {
    init_functionsRoutes_0_1319509027014999();
    init_http();
    init_crypto();
    init_books();
    __name(onRequestPost, "onRequestPost");
  }
});

// api/books/[id]/members.js
async function listMembers(env, book) {
  const { results } = await env.DB.prepare(
    `SELECT u.id, u.name, 1 AS owner, 0 AS ord FROM users u WHERE u.id = ?1
     UNION ALL
     SELECT u.id, u.name, 0, m.added_at FROM book_members m JOIN users u ON u.id = m.user_id WHERE m.book_id = ?2
     ORDER BY ord`
  ).bind(book.user_id, book.id).all();
  return results.map((r) => ({ id: r.id, name: r.name, owner: !!r.owner }));
}
async function onRequestGet({ env, data, params }) {
  const book = await accessibleBook(env, data.user.id, params.id, data.unlocked);
  return json({ members: await listMembers(env, book), isOwner: book.isOwner });
}
async function onRequestPost2({ request, env, data, params }) {
  const book = await accessibleBook(env, data.user.id, params.id, data.unlocked);
  if (!book.isOwner) throw new HttpError(403, "Only the owner can invite people.");
  const b = await readJson(request);
  const q = String(b.username || "").trim().replace(/^@/, "");
  if (!q) throw new HttpError(400, "Enter a username.");
  const { results } = await env.DB.prepare(
    q.includes("@") ? "SELECT id, name FROM users WHERE email = ? LIMIT 2" : "SELECT id, name FROM users WHERE name = ? COLLATE NOCASE LIMIT 2"
  ).bind(q.includes("@") ? q.toLowerCase() : q).all();
  if (!results.length) throw new HttpError(404, "No user with that username.");
  if (results.length > 1) throw new HttpError(409, "Several people use that name. Invite them by email instead.");
  const u = results[0];
  if (u.id === book.user_id) throw new HttpError(400, "That is the owner.");
  const res = await env.DB.prepare("INSERT OR IGNORE INTO book_members (book_id, user_id, added_at) VALUES (?, ?, ?)").bind(book.id, u.id, Date.now()).run();
  if (!res.meta.changes) throw new HttpError(409, u.name + " is already on this canvas.");
  return json({ members: await listMembers(env, book) }, 201);
}
async function onRequestDelete({ request, env, data, params }) {
  const book = await accessibleBook(env, data.user.id, params.id, data.unlocked);
  const uid = new URL(request.url).searchParams.get("user");
  if (!uid) throw new HttpError(400, "Missing user");
  if (!book.isOwner && uid !== data.user.id) throw new HttpError(403, "Not allowed");
  await env.DB.prepare("DELETE FROM book_members WHERE book_id = ? AND user_id = ?").bind(book.id, uid).run();
  return json({ members: await listMembers(env, book) });
}
var init_members = __esm({
  "api/books/[id]/members.js"() {
    init_functionsRoutes_0_1319509027014999();
    init_http();
    init_books();
    __name(listMembers, "listMembers");
    __name(onRequestGet, "onRequestGet");
    __name(onRequestPost2, "onRequestPost");
    __name(onRequestDelete, "onRequestDelete");
  }
});

// ../src/lib/auth.js
function readCookie(request, name) {
  const m = (request.headers.get("cookie") || "").match(new RegExp("(?:^|;\\s*)" + name + "=([^;]+)"));
  return m ? m[1] : null;
}
function sessionCookie(request, token, maxAgeSec) {
  const secure = new URL(request.url).protocol === "https:" ? "; Secure" : "";
  return `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAgeSec}${secure}`;
}
async function createSession(env, request, userId) {
  const token = randomToken();
  const now = Date.now();
  await env.DB.batch([
    env.DB.prepare("DELETE FROM sessions WHERE expires_at < ?").bind(now),
    env.DB.prepare("INSERT INTO sessions (id, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)").bind(await sha256Hex(token), userId, now, now + SESSION_MS)
  ]);
  return sessionCookie(request, token, SESSION_MS / 1e3);
}
async function getSessionUser(env, request) {
  const token = readCookie(request, COOKIE);
  if (!token) return null;
  return env.DB.prepare(
    `SELECT u.*, s.id AS session_id, s.arch_until FROM sessions s JOIN users u ON u.id = s.user_id
     WHERE s.id = ? AND s.expires_at > ?`
  ).bind(await sha256Hex(token), Date.now()).first();
}
async function destroySession(env, request) {
  const token = readCookie(request, COOKIE);
  if (token) await env.DB.prepare("DELETE FROM sessions WHERE id = ?").bind(await sha256Hex(token)).run();
  return sessionCookie(request, "", 0);
}
async function rateLimit(env, key, max, windowSec) {
  const now = Date.now(), reset = now + windowSec * 1e3;
  const row = await env.DB.prepare(
    `INSERT INTO rate_limits (key, count, reset_at) VALUES (?, 1, ?)
     ON CONFLICT(key) DO UPDATE SET
       count = CASE WHEN reset_at < ? THEN 1 ELSE count + 1 END,
       reset_at = CASE WHEN reset_at < ? THEN ? ELSE reset_at END
     RETURNING count`
  ).bind(key, reset, now, now, reset).first();
  if (row.count > max) throw new HttpError(429, "Too many attempts. Please try again later.");
}
var COOKIE, SESSION_MS, publicUser, clearLimit, refundLimit;
var init_auth = __esm({
  "../src/lib/auth.js"() {
    init_functionsRoutes_0_1319509027014999();
    init_crypto();
    init_http();
    COOKIE = "palett_session";
    SESSION_MS = 30 * 24 * 3600 * 1e3;
    publicUser = /* @__PURE__ */ __name((u) => ({
      id: u.id,
      name: u.name,
      email: u.email,
      theme: u.theme,
      treeOpen: !!u.tree_open
    }), "publicUser");
    __name(readCookie, "readCookie");
    __name(sessionCookie, "sessionCookie");
    __name(createSession, "createSession");
    __name(getSessionUser, "getSessionUser");
    __name(destroySession, "destroySession");
    __name(rateLimit, "rateLimit");
    clearLimit = /* @__PURE__ */ __name((env, key) => env.DB.prepare("DELETE FROM rate_limits WHERE key = ?").bind(key).run(), "clearLimit");
    refundLimit = /* @__PURE__ */ __name((env, key) => env.DB.prepare("UPDATE rate_limits SET count = MAX(count - 1, 0) WHERE key = ?").bind(key).run(), "refundLimit");
  }
});

// (disabled):crypto
var require_crypto = __commonJS({
  "(disabled):crypto"() {
    init_functionsRoutes_0_1319509027014999();
  }
});

// ../node_modules/bcryptjs/index.js
function randomBytes(len) {
  try {
    return crypto.getRandomValues(new Uint8Array(len));
  } catch {
  }
  try {
    return import_crypto3.default.randomBytes(len);
  } catch {
  }
  if (!randomFallback) {
    throw Error(
      "Neither WebCryptoAPI nor a crypto module is available. Use bcrypt.setRandomFallback to set an alternative"
    );
  }
  return randomFallback(len);
}
function setRandomFallback(random) {
  randomFallback = random;
}
function genSaltSync(rounds, seed_length) {
  rounds = rounds || GENSALT_DEFAULT_LOG2_ROUNDS;
  if (typeof rounds !== "number")
    throw Error(
      "Illegal arguments: " + typeof rounds + ", " + typeof seed_length
    );
  if (rounds < 4) rounds = 4;
  else if (rounds > 31) rounds = 31;
  var salt = [];
  salt.push("$2b$");
  if (rounds < 10) salt.push("0");
  salt.push(rounds.toString());
  salt.push("$");
  salt.push(base64_encode(randomBytes(BCRYPT_SALT_LEN), BCRYPT_SALT_LEN));
  return salt.join("");
}
function genSalt(rounds, seed_length, callback) {
  if (typeof seed_length === "function")
    callback = seed_length, seed_length = void 0;
  if (typeof rounds === "function") callback = rounds, rounds = void 0;
  if (typeof rounds === "undefined") rounds = GENSALT_DEFAULT_LOG2_ROUNDS;
  else if (typeof rounds !== "number")
    throw Error("illegal arguments: " + typeof rounds);
  function _async(callback2) {
    nextTick(function() {
      try {
        callback2(null, genSaltSync(rounds));
      } catch (err) {
        callback2(err);
      }
    });
  }
  __name(_async, "_async");
  if (callback) {
    if (typeof callback !== "function")
      throw Error("Illegal callback: " + typeof callback);
    _async(callback);
  } else
    return new Promise(function(resolve, reject) {
      _async(function(err, res) {
        if (err) {
          reject(err);
          return;
        }
        resolve(res);
      });
    });
}
function hashSync(password, salt) {
  if (typeof salt === "undefined") salt = GENSALT_DEFAULT_LOG2_ROUNDS;
  if (typeof salt === "number") salt = genSaltSync(salt);
  if (typeof password !== "string" || typeof salt !== "string")
    throw Error("Illegal arguments: " + typeof password + ", " + typeof salt);
  return _hash(password, salt);
}
function hash(password, salt, callback, progressCallback) {
  function _async(callback2) {
    if (typeof password === "string" && typeof salt === "number")
      genSalt(salt, function(err, salt2) {
        _hash(password, salt2, callback2, progressCallback);
      });
    else if (typeof password === "string" && typeof salt === "string")
      _hash(password, salt, callback2, progressCallback);
    else
      nextTick(
        callback2.bind(
          this,
          Error("Illegal arguments: " + typeof password + ", " + typeof salt)
        )
      );
  }
  __name(_async, "_async");
  if (callback) {
    if (typeof callback !== "function")
      throw Error("Illegal callback: " + typeof callback);
    _async(callback);
  } else
    return new Promise(function(resolve, reject) {
      _async(function(err, res) {
        if (err) {
          reject(err);
          return;
        }
        resolve(res);
      });
    });
}
function safeStringCompare(known, unknown) {
  var diff = known.length ^ unknown.length;
  for (var i = 0; i < known.length; ++i) {
    diff |= known.charCodeAt(i) ^ unknown.charCodeAt(i);
  }
  return diff === 0;
}
function compareSync(password, hash2) {
  if (typeof password !== "string" || typeof hash2 !== "string")
    throw Error("Illegal arguments: " + typeof password + ", " + typeof hash2);
  if (hash2.length !== 60) return false;
  return safeStringCompare(
    hashSync(password, hash2.substring(0, hash2.length - 31)),
    hash2
  );
}
function compare(password, hashValue, callback, progressCallback) {
  function _async(callback2) {
    if (typeof password !== "string" || typeof hashValue !== "string") {
      nextTick(
        callback2.bind(
          this,
          Error(
            "Illegal arguments: " + typeof password + ", " + typeof hashValue
          )
        )
      );
      return;
    }
    if (hashValue.length !== 60) {
      nextTick(callback2.bind(this, null, false));
      return;
    }
    hash(
      password,
      hashValue.substring(0, 29),
      function(err, comp) {
        if (err) callback2(err);
        else callback2(null, safeStringCompare(comp, hashValue));
      },
      progressCallback
    );
  }
  __name(_async, "_async");
  if (callback) {
    if (typeof callback !== "function")
      throw Error("Illegal callback: " + typeof callback);
    _async(callback);
  } else
    return new Promise(function(resolve, reject) {
      _async(function(err, res) {
        if (err) {
          reject(err);
          return;
        }
        resolve(res);
      });
    });
}
function getRounds(hash2) {
  if (typeof hash2 !== "string")
    throw Error("Illegal arguments: " + typeof hash2);
  return parseInt(hash2.split("$")[2], 10);
}
function getSalt(hash2) {
  if (typeof hash2 !== "string")
    throw Error("Illegal arguments: " + typeof hash2);
  if (hash2.length !== 60)
    throw Error("Illegal hash length: " + hash2.length + " != 60");
  return hash2.substring(0, 29);
}
function truncates(password) {
  if (typeof password !== "string")
    throw Error("Illegal arguments: " + typeof password);
  return utf8Length(password) > 72;
}
function utf8Length(string) {
  var len = 0, c = 0;
  for (var i = 0; i < string.length; ++i) {
    c = string.charCodeAt(i);
    if (c < 128) len += 1;
    else if (c < 2048) len += 2;
    else if ((c & 64512) === 55296 && (string.charCodeAt(i + 1) & 64512) === 56320) {
      ++i;
      len += 4;
    } else len += 3;
  }
  return len;
}
function utf8Array(string) {
  var offset = 0, c1, c2;
  var buffer = new Array(utf8Length(string));
  for (var i = 0, k = string.length; i < k; ++i) {
    c1 = string.charCodeAt(i);
    if (c1 < 128) {
      buffer[offset++] = c1;
    } else if (c1 < 2048) {
      buffer[offset++] = c1 >> 6 | 192;
      buffer[offset++] = c1 & 63 | 128;
    } else if ((c1 & 64512) === 55296 && ((c2 = string.charCodeAt(i + 1)) & 64512) === 56320) {
      c1 = 65536 + ((c1 & 1023) << 10) + (c2 & 1023);
      ++i;
      buffer[offset++] = c1 >> 18 | 240;
      buffer[offset++] = c1 >> 12 & 63 | 128;
      buffer[offset++] = c1 >> 6 & 63 | 128;
      buffer[offset++] = c1 & 63 | 128;
    } else {
      buffer[offset++] = c1 >> 12 | 224;
      buffer[offset++] = c1 >> 6 & 63 | 128;
      buffer[offset++] = c1 & 63 | 128;
    }
  }
  return buffer;
}
function base64_encode(b, len) {
  var off = 0, rs = [], c1, c2;
  if (len <= 0 || len > b.length) throw Error("Illegal len: " + len);
  while (off < len) {
    c1 = b[off++] & 255;
    rs.push(BASE64_CODE[c1 >> 2 & 63]);
    c1 = (c1 & 3) << 4;
    if (off >= len) {
      rs.push(BASE64_CODE[c1 & 63]);
      break;
    }
    c2 = b[off++] & 255;
    c1 |= c2 >> 4 & 15;
    rs.push(BASE64_CODE[c1 & 63]);
    c1 = (c2 & 15) << 2;
    if (off >= len) {
      rs.push(BASE64_CODE[c1 & 63]);
      break;
    }
    c2 = b[off++] & 255;
    c1 |= c2 >> 6 & 3;
    rs.push(BASE64_CODE[c1 & 63]);
    rs.push(BASE64_CODE[c2 & 63]);
  }
  return rs.join("");
}
function base64_decode(s, len) {
  var off = 0, slen = s.length, olen = 0, rs = [], c1, c2, c3, c4, o, code;
  if (len <= 0) throw Error("Illegal len: " + len);
  while (off < slen - 1 && olen < len) {
    code = s.charCodeAt(off++);
    c1 = code < BASE64_INDEX.length ? BASE64_INDEX[code] : -1;
    code = s.charCodeAt(off++);
    c2 = code < BASE64_INDEX.length ? BASE64_INDEX[code] : -1;
    if (c1 == -1 || c2 == -1) break;
    o = c1 << 2 >>> 0;
    o |= (c2 & 48) >> 4;
    rs.push(String.fromCharCode(o));
    if (++olen >= len || off >= slen) break;
    code = s.charCodeAt(off++);
    c3 = code < BASE64_INDEX.length ? BASE64_INDEX[code] : -1;
    if (c3 == -1) break;
    o = (c2 & 15) << 4 >>> 0;
    o |= (c3 & 60) >> 2;
    rs.push(String.fromCharCode(o));
    if (++olen >= len || off >= slen) break;
    code = s.charCodeAt(off++);
    c4 = code < BASE64_INDEX.length ? BASE64_INDEX[code] : -1;
    o = (c3 & 3) << 6 >>> 0;
    o |= c4;
    rs.push(String.fromCharCode(o));
    ++olen;
  }
  var res = [];
  for (off = 0; off < olen; off++) res.push(rs[off].charCodeAt(0));
  return res;
}
function _encipher(lr, off, P, S) {
  var n, l = lr[off], r = lr[off + 1];
  l ^= P[0];
  n = S[l >>> 24];
  n += S[256 | l >> 16 & 255];
  n ^= S[512 | l >> 8 & 255];
  n += S[768 | l & 255];
  r ^= n ^ P[1];
  n = S[r >>> 24];
  n += S[256 | r >> 16 & 255];
  n ^= S[512 | r >> 8 & 255];
  n += S[768 | r & 255];
  l ^= n ^ P[2];
  n = S[l >>> 24];
  n += S[256 | l >> 16 & 255];
  n ^= S[512 | l >> 8 & 255];
  n += S[768 | l & 255];
  r ^= n ^ P[3];
  n = S[r >>> 24];
  n += S[256 | r >> 16 & 255];
  n ^= S[512 | r >> 8 & 255];
  n += S[768 | r & 255];
  l ^= n ^ P[4];
  n = S[l >>> 24];
  n += S[256 | l >> 16 & 255];
  n ^= S[512 | l >> 8 & 255];
  n += S[768 | l & 255];
  r ^= n ^ P[5];
  n = S[r >>> 24];
  n += S[256 | r >> 16 & 255];
  n ^= S[512 | r >> 8 & 255];
  n += S[768 | r & 255];
  l ^= n ^ P[6];
  n = S[l >>> 24];
  n += S[256 | l >> 16 & 255];
  n ^= S[512 | l >> 8 & 255];
  n += S[768 | l & 255];
  r ^= n ^ P[7];
  n = S[r >>> 24];
  n += S[256 | r >> 16 & 255];
  n ^= S[512 | r >> 8 & 255];
  n += S[768 | r & 255];
  l ^= n ^ P[8];
  n = S[l >>> 24];
  n += S[256 | l >> 16 & 255];
  n ^= S[512 | l >> 8 & 255];
  n += S[768 | l & 255];
  r ^= n ^ P[9];
  n = S[r >>> 24];
  n += S[256 | r >> 16 & 255];
  n ^= S[512 | r >> 8 & 255];
  n += S[768 | r & 255];
  l ^= n ^ P[10];
  n = S[l >>> 24];
  n += S[256 | l >> 16 & 255];
  n ^= S[512 | l >> 8 & 255];
  n += S[768 | l & 255];
  r ^= n ^ P[11];
  n = S[r >>> 24];
  n += S[256 | r >> 16 & 255];
  n ^= S[512 | r >> 8 & 255];
  n += S[768 | r & 255];
  l ^= n ^ P[12];
  n = S[l >>> 24];
  n += S[256 | l >> 16 & 255];
  n ^= S[512 | l >> 8 & 255];
  n += S[768 | l & 255];
  r ^= n ^ P[13];
  n = S[r >>> 24];
  n += S[256 | r >> 16 & 255];
  n ^= S[512 | r >> 8 & 255];
  n += S[768 | r & 255];
  l ^= n ^ P[14];
  n = S[l >>> 24];
  n += S[256 | l >> 16 & 255];
  n ^= S[512 | l >> 8 & 255];
  n += S[768 | l & 255];
  r ^= n ^ P[15];
  n = S[r >>> 24];
  n += S[256 | r >> 16 & 255];
  n ^= S[512 | r >> 8 & 255];
  n += S[768 | r & 255];
  l ^= n ^ P[16];
  lr[off] = r ^ P[BLOWFISH_NUM_ROUNDS + 1];
  lr[off + 1] = l;
  return lr;
}
function _streamtoword(data, offp) {
  for (var i = 0, word = 0; i < 4; ++i)
    word = word << 8 | data[offp] & 255, offp = (offp + 1) % data.length;
  return { key: word, offp };
}
function _key(key, P, S) {
  var offset = 0, lr = [0, 0], plen = P.length, slen = S.length, sw;
  for (var i = 0; i < plen; i++)
    sw = _streamtoword(key, offset), offset = sw.offp, P[i] = P[i] ^ sw.key;
  for (i = 0; i < plen; i += 2)
    lr = _encipher(lr, 0, P, S), P[i] = lr[0], P[i + 1] = lr[1];
  for (i = 0; i < slen; i += 2)
    lr = _encipher(lr, 0, P, S), S[i] = lr[0], S[i + 1] = lr[1];
}
function _ekskey(data, key, P, S) {
  var offp = 0, lr = [0, 0], plen = P.length, slen = S.length, sw;
  for (var i = 0; i < plen; i++)
    sw = _streamtoword(key, offp), offp = sw.offp, P[i] = P[i] ^ sw.key;
  offp = 0;
  for (i = 0; i < plen; i += 2)
    sw = _streamtoword(data, offp), offp = sw.offp, lr[0] ^= sw.key, sw = _streamtoword(data, offp), offp = sw.offp, lr[1] ^= sw.key, lr = _encipher(lr, 0, P, S), P[i] = lr[0], P[i + 1] = lr[1];
  for (i = 0; i < slen; i += 2)
    sw = _streamtoword(data, offp), offp = sw.offp, lr[0] ^= sw.key, sw = _streamtoword(data, offp), offp = sw.offp, lr[1] ^= sw.key, lr = _encipher(lr, 0, P, S), S[i] = lr[0], S[i + 1] = lr[1];
}
function _crypt(b, salt, rounds, callback, progressCallback) {
  var cdata = C_ORIG.slice(), clen = cdata.length, err;
  if (rounds < 4 || rounds > 31) {
    err = Error("Illegal number of rounds (4-31): " + rounds);
    if (callback) {
      nextTick(callback.bind(this, err));
      return;
    } else throw err;
  }
  if (salt.length !== BCRYPT_SALT_LEN) {
    err = Error(
      "Illegal salt length: " + salt.length + " != " + BCRYPT_SALT_LEN
    );
    if (callback) {
      nextTick(callback.bind(this, err));
      return;
    } else throw err;
  }
  rounds = 1 << rounds >>> 0;
  var P, S, i = 0, j;
  if (typeof Int32Array === "function") {
    P = new Int32Array(P_ORIG);
    S = new Int32Array(S_ORIG);
  } else {
    P = P_ORIG.slice();
    S = S_ORIG.slice();
  }
  _ekskey(salt, b, P, S);
  function next() {
    if (progressCallback) progressCallback(i / rounds);
    if (i < rounds) {
      var start = Date.now();
      for (; i < rounds; ) {
        i = i + 1;
        _key(b, P, S);
        _key(salt, P, S);
        if (Date.now() - start > MAX_EXECUTION_TIME) break;
      }
    } else {
      for (i = 0; i < 64; i++)
        for (j = 0; j < clen >> 1; j++) _encipher(cdata, j << 1, P, S);
      var ret = [];
      for (i = 0; i < clen; i++)
        ret.push((cdata[i] >> 24 & 255) >>> 0), ret.push((cdata[i] >> 16 & 255) >>> 0), ret.push((cdata[i] >> 8 & 255) >>> 0), ret.push((cdata[i] & 255) >>> 0);
      if (callback) {
        callback(null, ret);
        return;
      } else return ret;
    }
    if (callback) nextTick(next);
  }
  __name(next, "next");
  if (typeof callback !== "undefined") {
    next();
  } else {
    var res;
    while (true) if (typeof (res = next()) !== "undefined") return res || [];
  }
}
function _hash(password, salt, callback, progressCallback) {
  var err;
  if (typeof password !== "string" || typeof salt !== "string") {
    err = Error("Invalid string / salt: Not a string");
    if (callback) {
      nextTick(callback.bind(this, err));
      return;
    } else throw err;
  }
  var minor, offset;
  if (salt.charAt(0) !== "$" || salt.charAt(1) !== "2") {
    err = Error("Invalid salt version: " + salt.substring(0, 2));
    if (callback) {
      nextTick(callback.bind(this, err));
      return;
    } else throw err;
  }
  if (salt.charAt(2) === "$") minor = String.fromCharCode(0), offset = 3;
  else {
    minor = salt.charAt(2);
    if (minor !== "a" && minor !== "b" && minor !== "y" || salt.charAt(3) !== "$") {
      err = Error("Invalid salt revision: " + salt.substring(2, 4));
      if (callback) {
        nextTick(callback.bind(this, err));
        return;
      } else throw err;
    }
    offset = 4;
  }
  if (salt.charAt(offset + 2) > "$") {
    err = Error("Missing salt rounds");
    if (callback) {
      nextTick(callback.bind(this, err));
      return;
    } else throw err;
  }
  var r1 = parseInt(salt.substring(offset, offset + 1), 10) * 10, r2 = parseInt(salt.substring(offset + 1, offset + 2), 10), rounds = r1 + r2, real_salt = salt.substring(offset + 3, offset + 25);
  password += minor >= "a" ? "\0" : "";
  var passwordb = utf8Array(password), saltb = base64_decode(real_salt, BCRYPT_SALT_LEN);
  function finish(bytes) {
    var res = [];
    res.push("$2");
    if (minor >= "a") res.push(minor);
    res.push("$");
    if (rounds < 10) res.push("0");
    res.push(rounds.toString());
    res.push("$");
    res.push(base64_encode(saltb, saltb.length));
    res.push(base64_encode(bytes, C_ORIG.length * 4 - 1));
    return res.join("");
  }
  __name(finish, "finish");
  if (typeof callback == "undefined")
    return finish(_crypt(passwordb, saltb, rounds));
  else {
    _crypt(
      passwordb,
      saltb,
      rounds,
      function(err2, bytes) {
        if (err2) callback(err2, null);
        else callback(null, finish(bytes));
      },
      progressCallback
    );
  }
}
function encodeBase64(bytes, length) {
  return base64_encode(bytes, length);
}
function decodeBase64(string, length) {
  return base64_decode(string, length);
}
var import_crypto3, randomFallback, nextTick, BASE64_CODE, BASE64_INDEX, BCRYPT_SALT_LEN, GENSALT_DEFAULT_LOG2_ROUNDS, BLOWFISH_NUM_ROUNDS, MAX_EXECUTION_TIME, P_ORIG, S_ORIG, C_ORIG, bcryptjs_default;
var init_bcryptjs = __esm({
  "../node_modules/bcryptjs/index.js"() {
    init_functionsRoutes_0_1319509027014999();
    import_crypto3 = __toESM(require_crypto(), 1);
    randomFallback = null;
    __name(randomBytes, "randomBytes");
    __name(setRandomFallback, "setRandomFallback");
    __name(genSaltSync, "genSaltSync");
    __name(genSalt, "genSalt");
    __name(hashSync, "hashSync");
    __name(hash, "hash");
    __name(safeStringCompare, "safeStringCompare");
    __name(compareSync, "compareSync");
    __name(compare, "compare");
    __name(getRounds, "getRounds");
    __name(getSalt, "getSalt");
    __name(truncates, "truncates");
    nextTick = typeof setImmediate === "function" ? setImmediate : typeof scheduler === "object" && typeof scheduler.postTask === "function" ? scheduler.postTask.bind(scheduler) : setTimeout;
    __name(utf8Length, "utf8Length");
    __name(utf8Array, "utf8Array");
    BASE64_CODE = "./ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split("");
    BASE64_INDEX = [
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      0,
      1,
      54,
      55,
      56,
      57,
      58,
      59,
      60,
      61,
      62,
      63,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      2,
      3,
      4,
      5,
      6,
      7,
      8,
      9,
      10,
      11,
      12,
      13,
      14,
      15,
      16,
      17,
      18,
      19,
      20,
      21,
      22,
      23,
      24,
      25,
      26,
      27,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      28,
      29,
      30,
      31,
      32,
      33,
      34,
      35,
      36,
      37,
      38,
      39,
      40,
      41,
      42,
      43,
      44,
      45,
      46,
      47,
      48,
      49,
      50,
      51,
      52,
      53,
      -1,
      -1,
      -1,
      -1,
      -1
    ];
    __name(base64_encode, "base64_encode");
    __name(base64_decode, "base64_decode");
    BCRYPT_SALT_LEN = 16;
    GENSALT_DEFAULT_LOG2_ROUNDS = 10;
    BLOWFISH_NUM_ROUNDS = 16;
    MAX_EXECUTION_TIME = 100;
    P_ORIG = [
      608135816,
      2242054355,
      320440878,
      57701188,
      2752067618,
      698298832,
      137296536,
      3964562569,
      1160258022,
      953160567,
      3193202383,
      887688300,
      3232508343,
      3380367581,
      1065670069,
      3041331479,
      2450970073,
      2306472731
    ];
    S_ORIG = [
      3509652390,
      2564797868,
      805139163,
      3491422135,
      3101798381,
      1780907670,
      3128725573,
      4046225305,
      614570311,
      3012652279,
      134345442,
      2240740374,
      1667834072,
      1901547113,
      2757295779,
      4103290238,
      227898511,
      1921955416,
      1904987480,
      2182433518,
      2069144605,
      3260701109,
      2620446009,
      720527379,
      3318853667,
      677414384,
      3393288472,
      3101374703,
      2390351024,
      1614419982,
      1822297739,
      2954791486,
      3608508353,
      3174124327,
      2024746970,
      1432378464,
      3864339955,
      2857741204,
      1464375394,
      1676153920,
      1439316330,
      715854006,
      3033291828,
      289532110,
      2706671279,
      2087905683,
      3018724369,
      1668267050,
      732546397,
      1947742710,
      3462151702,
      2609353502,
      2950085171,
      1814351708,
      2050118529,
      680887927,
      999245976,
      1800124847,
      3300911131,
      1713906067,
      1641548236,
      4213287313,
      1216130144,
      1575780402,
      4018429277,
      3917837745,
      3693486850,
      3949271944,
      596196993,
      3549867205,
      258830323,
      2213823033,
      772490370,
      2760122372,
      1774776394,
      2652871518,
      566650946,
      4142492826,
      1728879713,
      2882767088,
      1783734482,
      3629395816,
      2517608232,
      2874225571,
      1861159788,
      326777828,
      3124490320,
      2130389656,
      2716951837,
      967770486,
      1724537150,
      2185432712,
      2364442137,
      1164943284,
      2105845187,
      998989502,
      3765401048,
      2244026483,
      1075463327,
      1455516326,
      1322494562,
      910128902,
      469688178,
      1117454909,
      936433444,
      3490320968,
      3675253459,
      1240580251,
      122909385,
      2157517691,
      634681816,
      4142456567,
      3825094682,
      3061402683,
      2540495037,
      79693498,
      3249098678,
      1084186820,
      1583128258,
      426386531,
      1761308591,
      1047286709,
      322548459,
      995290223,
      1845252383,
      2603652396,
      3431023940,
      2942221577,
      3202600964,
      3727903485,
      1712269319,
      422464435,
      3234572375,
      1170764815,
      3523960633,
      3117677531,
      1434042557,
      442511882,
      3600875718,
      1076654713,
      1738483198,
      4213154764,
      2393238008,
      3677496056,
      1014306527,
      4251020053,
      793779912,
      2902807211,
      842905082,
      4246964064,
      1395751752,
      1040244610,
      2656851899,
      3396308128,
      445077038,
      3742853595,
      3577915638,
      679411651,
      2892444358,
      2354009459,
      1767581616,
      3150600392,
      3791627101,
      3102740896,
      284835224,
      4246832056,
      1258075500,
      768725851,
      2589189241,
      3069724005,
      3532540348,
      1274779536,
      3789419226,
      2764799539,
      1660621633,
      3471099624,
      4011903706,
      913787905,
      3497959166,
      737222580,
      2514213453,
      2928710040,
      3937242737,
      1804850592,
      3499020752,
      2949064160,
      2386320175,
      2390070455,
      2415321851,
      4061277028,
      2290661394,
      2416832540,
      1336762016,
      1754252060,
      3520065937,
      3014181293,
      791618072,
      3188594551,
      3933548030,
      2332172193,
      3852520463,
      3043980520,
      413987798,
      3465142937,
      3030929376,
      4245938359,
      2093235073,
      3534596313,
      375366246,
      2157278981,
      2479649556,
      555357303,
      3870105701,
      2008414854,
      3344188149,
      4221384143,
      3956125452,
      2067696032,
      3594591187,
      2921233993,
      2428461,
      544322398,
      577241275,
      1471733935,
      610547355,
      4027169054,
      1432588573,
      1507829418,
      2025931657,
      3646575487,
      545086370,
      48609733,
      2200306550,
      1653985193,
      298326376,
      1316178497,
      3007786442,
      2064951626,
      458293330,
      2589141269,
      3591329599,
      3164325604,
      727753846,
      2179363840,
      146436021,
      1461446943,
      4069977195,
      705550613,
      3059967265,
      3887724982,
      4281599278,
      3313849956,
      1404054877,
      2845806497,
      146425753,
      1854211946,
      1266315497,
      3048417604,
      3681880366,
      3289982499,
      290971e4,
      1235738493,
      2632868024,
      2414719590,
      3970600049,
      1771706367,
      1449415276,
      3266420449,
      422970021,
      1963543593,
      2690192192,
      3826793022,
      1062508698,
      1531092325,
      1804592342,
      2583117782,
      2714934279,
      4024971509,
      1294809318,
      4028980673,
      1289560198,
      2221992742,
      1669523910,
      35572830,
      157838143,
      1052438473,
      1016535060,
      1802137761,
      1753167236,
      1386275462,
      3080475397,
      2857371447,
      1040679964,
      2145300060,
      2390574316,
      1461121720,
      2956646967,
      4031777805,
      4028374788,
      33600511,
      2920084762,
      1018524850,
      629373528,
      3691585981,
      3515945977,
      2091462646,
      2486323059,
      586499841,
      988145025,
      935516892,
      3367335476,
      2599673255,
      2839830854,
      265290510,
      3972581182,
      2759138881,
      3795373465,
      1005194799,
      847297441,
      406762289,
      1314163512,
      1332590856,
      1866599683,
      4127851711,
      750260880,
      613907577,
      1450815602,
      3165620655,
      3734664991,
      3650291728,
      3012275730,
      3704569646,
      1427272223,
      778793252,
      1343938022,
      2676280711,
      2052605720,
      1946737175,
      3164576444,
      3914038668,
      3967478842,
      3682934266,
      1661551462,
      3294938066,
      4011595847,
      840292616,
      3712170807,
      616741398,
      312560963,
      711312465,
      1351876610,
      322626781,
      1910503582,
      271666773,
      2175563734,
      1594956187,
      70604529,
      3617834859,
      1007753275,
      1495573769,
      4069517037,
      2549218298,
      2663038764,
      504708206,
      2263041392,
      3941167025,
      2249088522,
      1514023603,
      1998579484,
      1312622330,
      694541497,
      2582060303,
      2151582166,
      1382467621,
      776784248,
      2618340202,
      3323268794,
      2497899128,
      2784771155,
      503983604,
      4076293799,
      907881277,
      423175695,
      432175456,
      1378068232,
      4145222326,
      3954048622,
      3938656102,
      3820766613,
      2793130115,
      2977904593,
      26017576,
      3274890735,
      3194772133,
      1700274565,
      1756076034,
      4006520079,
      3677328699,
      720338349,
      1533947780,
      354530856,
      688349552,
      3973924725,
      1637815568,
      332179504,
      3949051286,
      53804574,
      2852348879,
      3044236432,
      1282449977,
      3583942155,
      3416972820,
      4006381244,
      1617046695,
      2628476075,
      3002303598,
      1686838959,
      431878346,
      2686675385,
      1700445008,
      1080580658,
      1009431731,
      832498133,
      3223435511,
      2605976345,
      2271191193,
      2516031870,
      1648197032,
      4164389018,
      2548247927,
      300782431,
      375919233,
      238389289,
      3353747414,
      2531188641,
      2019080857,
      1475708069,
      455242339,
      2609103871,
      448939670,
      3451063019,
      1395535956,
      2413381860,
      1841049896,
      1491858159,
      885456874,
      4264095073,
      4001119347,
      1565136089,
      3898914787,
      1108368660,
      540939232,
      1173283510,
      2745871338,
      3681308437,
      4207628240,
      3343053890,
      4016749493,
      1699691293,
      1103962373,
      3625875870,
      2256883143,
      3830138730,
      1031889488,
      3479347698,
      1535977030,
      4236805024,
      3251091107,
      2132092099,
      1774941330,
      1199868427,
      1452454533,
      157007616,
      2904115357,
      342012276,
      595725824,
      1480756522,
      206960106,
      497939518,
      591360097,
      863170706,
      2375253569,
      3596610801,
      1814182875,
      2094937945,
      3421402208,
      1082520231,
      3463918190,
      2785509508,
      435703966,
      3908032597,
      1641649973,
      2842273706,
      3305899714,
      1510255612,
      2148256476,
      2655287854,
      3276092548,
      4258621189,
      236887753,
      3681803219,
      274041037,
      1734335097,
      3815195456,
      3317970021,
      1899903192,
      1026095262,
      4050517792,
      356393447,
      2410691914,
      3873677099,
      3682840055,
      3913112168,
      2491498743,
      4132185628,
      2489919796,
      1091903735,
      1979897079,
      3170134830,
      3567386728,
      3557303409,
      857797738,
      1136121015,
      1342202287,
      507115054,
      2535736646,
      337727348,
      3213592640,
      1301675037,
      2528481711,
      1895095763,
      1721773893,
      3216771564,
      62756741,
      2142006736,
      835421444,
      2531993523,
      1442658625,
      3659876326,
      2882144922,
      676362277,
      1392781812,
      170690266,
      3921047035,
      1759253602,
      3611846912,
      1745797284,
      664899054,
      1329594018,
      3901205900,
      3045908486,
      2062866102,
      2865634940,
      3543621612,
      3464012697,
      1080764994,
      553557557,
      3656615353,
      3996768171,
      991055499,
      499776247,
      1265440854,
      648242737,
      3940784050,
      980351604,
      3713745714,
      1749149687,
      3396870395,
      4211799374,
      3640570775,
      1161844396,
      3125318951,
      1431517754,
      545492359,
      4268468663,
      3499529547,
      1437099964,
      2702547544,
      3433638243,
      2581715763,
      2787789398,
      1060185593,
      1593081372,
      2418618748,
      4260947970,
      69676912,
      2159744348,
      86519011,
      2512459080,
      3838209314,
      1220612927,
      3339683548,
      133810670,
      1090789135,
      1078426020,
      1569222167,
      845107691,
      3583754449,
      4072456591,
      1091646820,
      628848692,
      1613405280,
      3757631651,
      526609435,
      236106946,
      48312990,
      2942717905,
      3402727701,
      1797494240,
      859738849,
      992217954,
      4005476642,
      2243076622,
      3870952857,
      3732016268,
      765654824,
      3490871365,
      2511836413,
      1685915746,
      3888969200,
      1414112111,
      2273134842,
      3281911079,
      4080962846,
      172450625,
      2569994100,
      980381355,
      4109958455,
      2819808352,
      2716589560,
      2568741196,
      3681446669,
      3329971472,
      1835478071,
      660984891,
      3704678404,
      4045999559,
      3422617507,
      3040415634,
      1762651403,
      1719377915,
      3470491036,
      2693910283,
      3642056355,
      3138596744,
      1364962596,
      2073328063,
      1983633131,
      926494387,
      3423689081,
      2150032023,
      4096667949,
      1749200295,
      3328846651,
      309677260,
      2016342300,
      1779581495,
      3079819751,
      111262694,
      1274766160,
      443224088,
      298511866,
      1025883608,
      3806446537,
      1145181785,
      168956806,
      3641502830,
      3584813610,
      1689216846,
      3666258015,
      3200248200,
      1692713982,
      2646376535,
      4042768518,
      1618508792,
      1610833997,
      3523052358,
      4130873264,
      2001055236,
      3610705100,
      2202168115,
      4028541809,
      2961195399,
      1006657119,
      2006996926,
      3186142756,
      1430667929,
      3210227297,
      1314452623,
      4074634658,
      4101304120,
      2273951170,
      1399257539,
      3367210612,
      3027628629,
      1190975929,
      2062231137,
      2333990788,
      2221543033,
      2438960610,
      1181637006,
      548689776,
      2362791313,
      3372408396,
      3104550113,
      3145860560,
      296247880,
      1970579870,
      3078560182,
      3769228297,
      1714227617,
      3291629107,
      3898220290,
      166772364,
      1251581989,
      493813264,
      448347421,
      195405023,
      2709975567,
      677966185,
      3703036547,
      1463355134,
      2715995803,
      1338867538,
      1343315457,
      2802222074,
      2684532164,
      233230375,
      2599980071,
      2000651841,
      3277868038,
      1638401717,
      4028070440,
      3237316320,
      6314154,
      819756386,
      300326615,
      590932579,
      1405279636,
      3267499572,
      3150704214,
      2428286686,
      3959192993,
      3461946742,
      1862657033,
      1266418056,
      963775037,
      2089974820,
      2263052895,
      1917689273,
      448879540,
      3550394620,
      3981727096,
      150775221,
      3627908307,
      1303187396,
      508620638,
      2975983352,
      2726630617,
      1817252668,
      1876281319,
      1457606340,
      908771278,
      3720792119,
      3617206836,
      2455994898,
      1729034894,
      1080033504,
      976866871,
      3556439503,
      2881648439,
      1522871579,
      1555064734,
      1336096578,
      3548522304,
      2579274686,
      3574697629,
      3205460757,
      3593280638,
      3338716283,
      3079412587,
      564236357,
      2993598910,
      1781952180,
      1464380207,
      3163844217,
      3332601554,
      1699332808,
      1393555694,
      1183702653,
      3581086237,
      1288719814,
      691649499,
      2847557200,
      2895455976,
      3193889540,
      2717570544,
      1781354906,
      1676643554,
      2592534050,
      3230253752,
      1126444790,
      2770207658,
      2633158820,
      2210423226,
      2615765581,
      2414155088,
      3127139286,
      673620729,
      2805611233,
      1269405062,
      4015350505,
      3341807571,
      4149409754,
      1057255273,
      2012875353,
      2162469141,
      2276492801,
      2601117357,
      993977747,
      3918593370,
      2654263191,
      753973209,
      36408145,
      2530585658,
      25011837,
      3520020182,
      2088578344,
      530523599,
      2918365339,
      1524020338,
      1518925132,
      3760827505,
      3759777254,
      1202760957,
      3985898139,
      3906192525,
      674977740,
      4174734889,
      2031300136,
      2019492241,
      3983892565,
      4153806404,
      3822280332,
      352677332,
      2297720250,
      60907813,
      90501309,
      3286998549,
      1016092578,
      2535922412,
      2839152426,
      457141659,
      509813237,
      4120667899,
      652014361,
      1966332200,
      2975202805,
      55981186,
      2327461051,
      676427537,
      3255491064,
      2882294119,
      3433927263,
      1307055953,
      942726286,
      933058658,
      2468411793,
      3933900994,
      4215176142,
      1361170020,
      2001714738,
      2830558078,
      3274259782,
      1222529897,
      1679025792,
      2729314320,
      3714953764,
      1770335741,
      151462246,
      3013232138,
      1682292957,
      1483529935,
      471910574,
      1539241949,
      458788160,
      3436315007,
      1807016891,
      3718408830,
      978976581,
      1043663428,
      3165965781,
      1927990952,
      4200891579,
      2372276910,
      3208408903,
      3533431907,
      1412390302,
      2931980059,
      4132332400,
      1947078029,
      3881505623,
      4168226417,
      2941484381,
      1077988104,
      1320477388,
      886195818,
      18198404,
      3786409e3,
      2509781533,
      112762804,
      3463356488,
      1866414978,
      891333506,
      18488651,
      661792760,
      1628790961,
      3885187036,
      3141171499,
      876946877,
      2693282273,
      1372485963,
      791857591,
      2686433993,
      3759982718,
      3167212022,
      3472953795,
      2716379847,
      445679433,
      3561995674,
      3504004811,
      3574258232,
      54117162,
      3331405415,
      2381918588,
      3769707343,
      4154350007,
      1140177722,
      4074052095,
      668550556,
      3214352940,
      367459370,
      261225585,
      2610173221,
      4209349473,
      3468074219,
      3265815641,
      314222801,
      3066103646,
      3808782860,
      282218597,
      3406013506,
      3773591054,
      379116347,
      1285071038,
      846784868,
      2669647154,
      3771962079,
      3550491691,
      2305946142,
      453669953,
      1268987020,
      3317592352,
      3279303384,
      3744833421,
      2610507566,
      3859509063,
      266596637,
      3847019092,
      517658769,
      3462560207,
      3443424879,
      370717030,
      4247526661,
      2224018117,
      4143653529,
      4112773975,
      2788324899,
      2477274417,
      1456262402,
      2901442914,
      1517677493,
      1846949527,
      2295493580,
      3734397586,
      2176403920,
      1280348187,
      1908823572,
      3871786941,
      846861322,
      1172426758,
      3287448474,
      3383383037,
      1655181056,
      3139813346,
      901632758,
      1897031941,
      2986607138,
      3066810236,
      3447102507,
      1393639104,
      373351379,
      950779232,
      625454576,
      3124240540,
      4148612726,
      2007998917,
      544563296,
      2244738638,
      2330496472,
      2058025392,
      1291430526,
      424198748,
      50039436,
      29584100,
      3605783033,
      2429876329,
      2791104160,
      1057563949,
      3255363231,
      3075367218,
      3463963227,
      1469046755,
      985887462
    ];
    C_ORIG = [
      1332899944,
      1700884034,
      1701343084,
      1684370003,
      1668446532,
      1869963892
    ];
    __name(_encipher, "_encipher");
    __name(_streamtoword, "_streamtoword");
    __name(_key, "_key");
    __name(_ekskey, "_ekskey");
    __name(_crypt, "_crypt");
    __name(_hash, "_hash");
    __name(encodeBase64, "encodeBase64");
    __name(decodeBase64, "decodeBase64");
    bcryptjs_default = {
      setRandomFallback,
      genSaltSync,
      genSalt,
      hashSync,
      hash,
      compareSync,
      compare,
      getRounds,
      getSalt,
      truncates,
      encodeBase64,
      decodeBase64
    };
  }
});

// ../src/lib/archive.js
async function makePass(sessionId, hash2) {
  const exp = Date.now() + ENTRY_TTL;
  const sig = await crypto.subtle.sign("HMAC", await macKey(hash2), enc2.encode(`${sessionId}|${exp}`));
  return { pass: `${exp}.${toHex(sig)}`, expiresAt: exp };
}
async function checkPass(pass, sessionId, hash2) {
  const [e, h] = String(pass || "").split(".");
  const exp = Number(e), now = Date.now();
  if (!exp || exp < now || exp > now + ENTRY_TTL || !/^[0-9a-f]{64}$/.test(h || "")) return false;
  const sig = Uint8Array.from(h.match(/../g), (x) => parseInt(x, 16));
  return crypto.subtle.verify("HMAC", await macKey(hash2), sig, enc2.encode(`${sessionId}|${exp}`));
}
function checkArchivePassword(pw, { min = 1 } = {}) {
  const bytes = new TextEncoder().encode(pw).length;
  if (bytes < min) throw new HttpError(400, `Use at least ${min} characters.`);
  if (bytes > 72) throw new HttpError(400, "Use at most 72 characters.");
}
async function verifyArchive(pw, stored) {
  try {
    if (String(stored).startsWith("pbkdf2$")) return { ok: await verifyPassword(pw, stored), upgrade: true };
    return { ok: await bcryptjs_default.compare(pw, stored), upgrade: false };
  } catch {
    return { ok: false, upgrade: false };
  }
}
var ENTRY_TTL, FOLDER_TTL, enc2, macKey, cost, hashArchive, isUnlocked;
var init_archive = __esm({
  "../src/lib/archive.js"() {
    init_functionsRoutes_0_1319509027014999();
    init_bcryptjs();
    init_http();
    init_crypto();
    ENTRY_TTL = 7e3;
    FOLDER_TTL = 2 * 60 * 1e3;
    enc2 = new TextEncoder();
    macKey = /* @__PURE__ */ __name((hash2) => crypto.subtle.importKey("raw", enc2.encode("archive-pass|" + hash2), { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]), "macKey");
    __name(makePass, "makePass");
    __name(checkPass, "checkPass");
    __name(checkArchivePassword, "checkArchivePassword");
    cost = /* @__PURE__ */ __name((env) => Math.min(12, Math.max(4, Number(env.BCRYPT_COST) || 10)), "cost");
    hashArchive = /* @__PURE__ */ __name((env, pw) => bcryptjs_default.hash(pw, cost(env)), "hashArchive");
    __name(verifyArchive, "verifyArchive");
    isUnlocked = /* @__PURE__ */ __name((user) => !!user && user.arch_until > Date.now(), "isUnlocked");
  }
});

// api/archive/enter.js
async function onRequestPost3({ request, env, data }) {
  const b = await readJson(request);
  const user = data.user;
  await rateLimit(env, `archp:${user.id}`, 60, 900);
  if (!user.arch_hash || !await checkPass(b.pass, user.session_id, user.arch_hash)) throw new HttpError(401, "Password not found");
  const expiresAt = Date.now() + FOLDER_TTL;
  await env.DB.prepare("UPDATE sessions SET arch_until = ? WHERE id = ?").bind(expiresAt, user.session_id).run();
  return json({ ok: true, unlocked: true, expiresAt });
}
var init_enter = __esm({
  "api/archive/enter.js"() {
    init_functionsRoutes_0_1319509027014999();
    init_http();
    init_auth();
    init_archive();
    __name(onRequestPost3, "onRequestPost");
  }
});

// api/archive/lock.js
async function onRequestPost4({ env, data }) {
  await env.DB.prepare("UPDATE sessions SET arch_until = 0 WHERE id = ?").bind(data.user.session_id).run();
  return json({ ok: true, unlocked: false });
}
var init_lock = __esm({
  "api/archive/lock.js"() {
    init_functionsRoutes_0_1319509027014999();
    init_http();
    __name(onRequestPost4, "onRequestPost");
  }
});

// api/archive/status.js
async function onRequestGet2({ data }) {
  return json({ hasPassword: !!data.user.arch_hash, unlocked: data.unlocked, expiresAt: data.unlocked ? data.user.arch_until : null });
}
var init_status = __esm({
  "api/archive/status.js"() {
    init_functionsRoutes_0_1319509027014999();
    init_http();
    __name(onRequestGet2, "onRequestGet");
  }
});

// api/archive/verify.js
async function onRequestPost5({ request, env, data }) {
  const b = await readJson(request);
  const password = String(b.password || "");
  const user = data.user;
  if (!password) throw new HttpError(401, "Password not found");
  const key = `arch:${user.id}`, day = `archd:${user.id}`;
  await rateLimit(env, key, 10, 900);
  await rateLimit(env, day, 30, 86400);
  let created = false, hash2 = user.arch_hash;
  if (!user.arch_hash) {
    if (b.create !== true) throw new HttpError(401, "Password not found");
    checkArchivePassword(password, { min: 1 });
    hash2 = await hashArchive(env, password);
    await env.DB.prepare("UPDATE users SET arch_hash = ? WHERE id = ?").bind(hash2, user.id).run();
    created = true;
  } else {
    if (new TextEncoder().encode(password).length > 72) throw new HttpError(401, "Password not found");
    const { ok, upgrade } = await verifyArchive(password, user.arch_hash);
    if (!ok) throw new HttpError(401, "Password not found");
    if (upgrade) {
      hash2 = await hashArchive(env, password);
      await env.DB.prepare("UPDATE users SET arch_hash = ? WHERE id = ?").bind(hash2, user.id).run();
    }
  }
  await clearLimit(env, key);
  await refundLimit(env, day);
  const { pass, expiresAt } = await makePass(user.session_id, hash2);
  return json({ ok: true, pass, expiresAt, created });
}
var init_verify = __esm({
  "api/archive/verify.js"() {
    init_functionsRoutes_0_1319509027014999();
    init_http();
    init_auth();
    init_archive();
    __name(onRequestPost5, "onRequestPost");
  }
});

// api/auth/login.js
async function onRequestPost6({ request, env }) {
  const b = await readJson(request);
  const email = String(b.email || "").trim().toLowerCase();
  const password = String(b.password || "");
  if (!email || !password || password.length > 200) throw new HttpError(400, "Enter your email and password.");
  const key = `login:${clientIp(request)}:${email}`;
  await rateLimit(env, key, 10, 900);
  const user = await env.DB.prepare("SELECT * FROM users WHERE email = ?").bind(email).first();
  const ok = await verifyPassword(password, user ? user.pw_hash : DUMMY_HASH);
  if (!user || !ok) throw new HttpError(401, "Incorrect email or password.");
  await clearLimit(env, key);
  const cookie = await createSession(env, request, user.id);
  return json({ user: publicUser(user) }, 200, { "set-cookie": cookie });
}
var init_login = __esm({
  "api/auth/login.js"() {
    init_functionsRoutes_0_1319509027014999();
    init_http();
    init_crypto();
    init_auth();
    __name(onRequestPost6, "onRequestPost");
  }
});

// api/auth/logout.js
async function onRequestPost7({ request, env }) {
  const cookie = await destroySession(env, request);
  return json({ ok: true }, 200, { "set-cookie": cookie });
}
var init_logout = __esm({
  "api/auth/logout.js"() {
    init_functionsRoutes_0_1319509027014999();
    init_http();
    init_auth();
    __name(onRequestPost7, "onRequestPost");
  }
});

// api/auth/signup.js
async function onRequestPost8({ request, env }) {
  const b = await readJson(request);
  const name = String(b.name || "").trim();
  const email = String(b.email || "").trim().toLowerCase();
  const password = String(b.password || "");
  if (!/^\S+@\S+\.\S+$/.test(email) || email.length > 254) throw new HttpError(400, "Enter a valid email address.");
  if (!name || name.length > 24) throw new HttpError(400, "Enter your name (max 24 characters).");
  if (password.length < 6 || password.length > 200) throw new HttpError(400, "Password must be at least 6 characters.");
  if (b.agreed !== true) throw new HttpError(400, "Please accept the Terms of Service and Privacy Policy.");
  await rateLimit(env, `signup:${clientIp(request)}`, 10, 3600);
  const id = newId(), now = Date.now();
  try {
    await env.DB.prepare(
      "INSERT INTO users (id, email, name, pw_hash, theme, tree_open, created_at, agreed_at) VALUES (?, ?, ?, ?, ?, 0, ?, ?)"
    ).bind(id, email, name, await hashPassword(password), "dark", now, now).run();
  } catch (e) {
    if (String(e).includes("UNIQUE")) throw new HttpError(409, "An account with this email already exists.");
    throw e;
  }
  const cookie = await createSession(env, request, id);
  return json({ user: publicUser({ id, name, email, theme: "dark", tree_open: 0 }) }, 201, { "set-cookie": cookie });
}
var init_signup = __esm({
  "api/auth/signup.js"() {
    init_functionsRoutes_0_1319509027014999();
    init_http();
    init_crypto();
    init_auth();
    __name(onRequestPost8, "onRequestPost");
  }
});

// api/books/[id]/index.js
async function onRequestGet3({ env, data, params }) {
  const book = await accessibleBook(env, data.user.id, params.id, data.unlocked);
  const { results } = await env.DB.prepare("SELECT data FROM book_chunks WHERE book_id = ? ORDER BY idx").bind(book.id).all();
  const raw = results.map((r) => r.data).join("") || "null";
  return new Response(`{"book":${JSON.stringify(bookMeta(book))},"payload":${raw}}`, {
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
  });
}
async function onRequestPut({ request, env, data, params }) {
  const book = await accessibleBook(env, data.user.id, params.id, data.unlocked);
  const b = await readJson(request, MAX_PAYLOAD + 4e5);
  if (!b.payload || typeof b.payload !== "object" || !Array.isArray(b.payload.objs)) throw new HttpError(400, "Invalid paintbook data");
  const text = JSON.stringify(b.payload);
  if (text.length > MAX_PAYLOAD) throw new HttpError(413, "This paintbook is too large to save. Remove some images.");
  const now = Date.now();
  const name = String(book.isOwner ? b.name ?? book.name : book.name).trim().slice(0, 60) || book.name;
  await env.DB.batch([
    env.DB.prepare("DELETE FROM book_chunks WHERE book_id = ?").bind(book.id),
    ...chunkStatements(env, book.id, text),
    env.DB.prepare("UPDATE books SET name = ?, thumb = ?, w = ?, h = ?, scroll = ?, size = ?, updated_at = ? WHERE id = ?").bind(name, cleanThumb(b.thumb), clampDim(b.w ?? book.w), clampDim(b.h ?? book.h), b.scroll ? 1 : 0, text.length, now, book.id)
  ]);
  return json({ book: { id: book.id, updated: now } });
}
async function onRequestPatch({ request, env, data, params }) {
  const book = await ownedBook(env, data.user.id, params.id, data.unlocked);
  const b = await readJson(request);
  if (b.arch !== void 0) {
    if (!data.unlocked) throw new HttpError(403, "Archive is locked");
    if (b.arch && !data.user.arch_hash) throw new HttpError(400, "Set an archive password first");
  }
  const sets = [], vals = [];
  if (b.name !== void 0) {
    const n = String(b.name).trim().slice(0, 60);
    if (!n) throw new HttpError(400, "Name required");
    sets.push("name = ?");
    vals.push(n);
  }
  if (b.title !== void 0) {
    sets.push("title = ?");
    vals.push(String(b.title).trim().slice(0, 80));
  }
  if (b.fav !== void 0) {
    sets.push("fav = ?");
    vals.push(b.fav ? 1 : 0);
  }
  if (b.arch !== void 0) {
    sets.push("arch = ?");
    vals.push(b.arch ? 1 : 0);
  }
  if (sets.length) await env.DB.prepare(`UPDATE books SET ${sets.join(", ")} WHERE id = ? AND user_id = ?`).bind(...vals, book.id, data.user.id).run();
  return json({ ok: true });
}
async function onRequestDelete2({ env, data, params }) {
  const book = await ownedBook(env, data.user.id, params.id, data.unlocked);
  await env.DB.batch([
    env.DB.prepare("DELETE FROM book_chunks WHERE book_id = ?").bind(book.id),
    env.DB.prepare("DELETE FROM books WHERE id = ? AND user_id = ?").bind(book.id, data.user.id)
  ]);
  return json({ ok: true });
}
var init_id = __esm({
  "api/books/[id]/index.js"() {
    init_functionsRoutes_0_1319509027014999();
    init_http();
    init_books();
    __name(onRequestGet3, "onRequestGet");
    __name(onRequestPut, "onRequestPut");
    __name(onRequestPatch, "onRequestPatch");
    __name(onRequestDelete2, "onRequestDelete");
  }
});

// api/books/index.js
async function onRequestGet4({ request, env, data }) {
  const archived = new URL(request.url).searchParams.get("archived") === "1";
  if (archived && !data.unlocked) throw new HttpError(403, "Archive is locked");
  let results;
  try {
    ({ results } = await env.DB.prepare(
      `SELECT ${META_COLS}, 0 AS shared FROM books WHERE user_id = ?1 AND arch = ?2
       UNION ALL
       SELECT ${META_COLS}, 1 AS shared FROM books WHERE ?2 = 0 AND arch = 0 AND id IN (SELECT book_id FROM book_members WHERE user_id = ?1)
       ORDER BY updated_at DESC`
    ).bind(data.user.id, archived ? 1 : 0).all());
  } catch (e) {
    ({ results } = await env.DB.prepare(
      `SELECT ${META_COLS}, 0 AS shared FROM books WHERE user_id = ? AND arch = ? ORDER BY updated_at DESC`
    ).bind(data.user.id, archived ? 1 : 0).all());
  }
  return json({ books: results.map(bookMeta) });
}
async function onRequestPost9({ request, env, data }) {
  const b = await readJson(request);
  const count = await env.DB.prepare("SELECT COUNT(*) AS n FROM books WHERE user_id = ?").bind(data.user.id).first();
  if (count.n >= MAX_BOOKS) throw new HttpError(403, `Limit of ${MAX_BOOKS} paintbooks reached.`);
  const name = String(b.name || "").trim().slice(0, 60) || "Untitled";
  const title = String(b.title || "").trim().slice(0, 80);
  const w = clampDim(b.w), h = clampDim(b.h), scroll = b.scroll ? 1 : 0;
  const bg = /^#[0-9a-f]{6}$/i.test(b.bg) ? b.bg : "#ffffff";
  const id = newId(), now = Date.now();
  const payload = JSON.stringify({ objs: [], imgs: {}, bg, nid: 1, w, h, scroll });
  await env.DB.batch([
    env.DB.prepare(
      `INSERT INTO books (id, user_id, name, title, fav, arch, w, h, scroll, thumb, size, created_at, updated_at)
       VALUES (?, ?, ?, ?, 0, 0, ?, ?, ?, '', ?, ?, ?)`
    ).bind(id, data.user.id, name, title, w, h, scroll, payload.length, now, now),
    ...chunkStatements(env, id, payload)
  ]);
  return json({ book: bookMeta({ id, name, title, fav: 0, arch: 0, w, h, scroll, thumb: "", created_at: now, updated_at: now }) }, 201);
}
var init_books2 = __esm({
  "api/books/index.js"() {
    init_functionsRoutes_0_1319509027014999();
    init_http();
    init_crypto();
    init_books();
    __name(onRequestGet4, "onRequestGet");
    __name(onRequestPost9, "onRequestPost");
  }
});

// api/me.js
async function onRequestGet5({ data }) {
  return json({ user: publicUser(data.user) });
}
async function onRequestPatch2({ request, env, data }) {
  const b = await readJson(request);
  const sets = [], vals = [];
  if (b.name !== void 0) {
    const n = String(b.name).trim();
    if (!n || n.length > 24) throw new HttpError(400, "Name must be 1\u201324 characters.");
    sets.push("name = ?");
    vals.push(n);
  }
  if (b.theme !== void 0) {
    if (!["dark", "light", "auto"].includes(b.theme)) throw new HttpError(400, "Invalid theme");
    sets.push("theme = ?");
    vals.push(b.theme);
  }
  if (b.treeOpen !== void 0) {
    sets.push("tree_open = ?");
    vals.push(b.treeOpen ? 1 : 0);
  }
  if (sets.length) await env.DB.prepare(`UPDATE users SET ${sets.join(", ")} WHERE id = ?`).bind(...vals, data.user.id).run();
  const row = await env.DB.prepare("SELECT * FROM users WHERE id = ?").bind(data.user.id).first();
  return json({ user: publicUser(row) });
}
async function onRequestDelete3({ env, data, request }) {
  const id = data.user.id;
  await env.DB.batch([
    env.DB.prepare("DELETE FROM book_members WHERE user_id = ? OR book_id IN (SELECT id FROM books WHERE user_id = ?)").bind(id, id),
    env.DB.prepare("DELETE FROM book_chunks WHERE book_id IN (SELECT id FROM books WHERE user_id = ?)").bind(id),
    env.DB.prepare("DELETE FROM books WHERE user_id = ?").bind(id),
    env.DB.prepare("DELETE FROM sessions WHERE user_id = ?").bind(id),
    env.DB.prepare("DELETE FROM users WHERE id = ?").bind(id)
  ]);
  return json({ ok: true }, 200, { "set-cookie": sessionCookie(request, "", 0) });
}
var init_me = __esm({
  "api/me.js"() {
    init_functionsRoutes_0_1319509027014999();
    init_http();
    init_auth();
    __name(onRequestGet5, "onRequestGet");
    __name(onRequestPatch2, "onRequestPatch");
    __name(onRequestDelete3, "onRequestDelete");
  }
});

// api/_middleware.js
async function onRequest({ request, env, next, data }) {
  try {
    if (!env.DB) throw new HttpError(500, 'D1 binding "DB" is not configured');
    const url = new URL(request.url);
    if (request.method !== "GET" && request.method !== "HEAD") {
      const origin = request.headers.get("origin");
      if (origin && origin !== url.origin) throw new HttpError(403, "Bad origin");
    }
    data.user = await getSessionUser(env, request);
    if (!PUBLIC.has(url.pathname) && !data.user) throw new HttpError(401, "Not signed in");
    data.unlocked = isUnlocked(data.user);
    const now = Date.now();
    if (data.unlocked && data.user.arch_until - now < FOLDER_TTL - 3e4) {
      await env.DB.prepare("UPDATE sessions SET arch_until = ? WHERE id = ?").bind(now + FOLDER_TTL, data.user.session_id).run();
    }
    return await next();
  } catch (e) {
    if (e instanceof HttpError) return json({ error: e.message }, e.status);
    console.error(e);
    return json({ error: "Server error" }, 500);
  }
}
var PUBLIC;
var init_middleware = __esm({
  "api/_middleware.js"() {
    init_functionsRoutes_0_1319509027014999();
    init_http();
    init_auth();
    init_archive();
    PUBLIC = /* @__PURE__ */ new Set(["/api/auth/login", "/api/auth/signup", "/api/auth/logout"]);
    __name(onRequest, "onRequest");
  }
});

// ../.wrangler/tmp/pages-DPlAUg/functionsRoutes-0.1319509027014999.mjs
var routes;
var init_functionsRoutes_0_1319509027014999 = __esm({
  "../.wrangler/tmp/pages-DPlAUg/functionsRoutes-0.1319509027014999.mjs"() {
    init_duplicate();
    init_members();
    init_members();
    init_members();
    init_enter();
    init_lock();
    init_status();
    init_verify();
    init_login();
    init_logout();
    init_signup();
    init_id();
    init_id();
    init_id();
    init_id();
    init_books2();
    init_books2();
    init_me();
    init_me();
    init_me();
    init_middleware();
    routes = [
      {
        routePath: "/api/books/:id/duplicate",
        mountPath: "/api/books/:id",
        method: "POST",
        middlewares: [],
        modules: [onRequestPost]
      },
      {
        routePath: "/api/books/:id/members",
        mountPath: "/api/books/:id",
        method: "DELETE",
        middlewares: [],
        modules: [onRequestDelete]
      },
      {
        routePath: "/api/books/:id/members",
        mountPath: "/api/books/:id",
        method: "GET",
        middlewares: [],
        modules: [onRequestGet]
      },
      {
        routePath: "/api/books/:id/members",
        mountPath: "/api/books/:id",
        method: "POST",
        middlewares: [],
        modules: [onRequestPost2]
      },
      {
        routePath: "/api/archive/enter",
        mountPath: "/api/archive",
        method: "POST",
        middlewares: [],
        modules: [onRequestPost3]
      },
      {
        routePath: "/api/archive/lock",
        mountPath: "/api/archive",
        method: "POST",
        middlewares: [],
        modules: [onRequestPost4]
      },
      {
        routePath: "/api/archive/status",
        mountPath: "/api/archive",
        method: "GET",
        middlewares: [],
        modules: [onRequestGet2]
      },
      {
        routePath: "/api/archive/verify",
        mountPath: "/api/archive",
        method: "POST",
        middlewares: [],
        modules: [onRequestPost5]
      },
      {
        routePath: "/api/auth/login",
        mountPath: "/api/auth",
        method: "POST",
        middlewares: [],
        modules: [onRequestPost6]
      },
      {
        routePath: "/api/auth/logout",
        mountPath: "/api/auth",
        method: "POST",
        middlewares: [],
        modules: [onRequestPost7]
      },
      {
        routePath: "/api/auth/signup",
        mountPath: "/api/auth",
        method: "POST",
        middlewares: [],
        modules: [onRequestPost8]
      },
      {
        routePath: "/api/books/:id",
        mountPath: "/api/books/:id",
        method: "DELETE",
        middlewares: [],
        modules: [onRequestDelete2]
      },
      {
        routePath: "/api/books/:id",
        mountPath: "/api/books/:id",
        method: "GET",
        middlewares: [],
        modules: [onRequestGet3]
      },
      {
        routePath: "/api/books/:id",
        mountPath: "/api/books/:id",
        method: "PATCH",
        middlewares: [],
        modules: [onRequestPatch]
      },
      {
        routePath: "/api/books/:id",
        mountPath: "/api/books/:id",
        method: "PUT",
        middlewares: [],
        modules: [onRequestPut]
      },
      {
        routePath: "/api/books",
        mountPath: "/api/books",
        method: "GET",
        middlewares: [],
        modules: [onRequestGet4]
      },
      {
        routePath: "/api/books",
        mountPath: "/api/books",
        method: "POST",
        middlewares: [],
        modules: [onRequestPost9]
      },
      {
        routePath: "/api/me",
        mountPath: "/api",
        method: "DELETE",
        middlewares: [],
        modules: [onRequestDelete3]
      },
      {
        routePath: "/api/me",
        mountPath: "/api",
        method: "GET",
        middlewares: [],
        modules: [onRequestGet5]
      },
      {
        routePath: "/api/me",
        mountPath: "/api",
        method: "PATCH",
        middlewares: [],
        modules: [onRequestPatch2]
      },
      {
        routePath: "/api",
        mountPath: "/api",
        method: "",
        middlewares: [onRequest],
        modules: []
      }
    ];
  }
});

// ../node_modules/wrangler/templates/pages-template-worker.ts
init_functionsRoutes_0_1319509027014999();

// ../node_modules/path-to-regexp/dist.es2015/index.js
init_functionsRoutes_0_1319509027014999();
function lexer(str) {
  var tokens = [];
  var i = 0;
  while (i < str.length) {
    var char = str[i];
    if (char === "*" || char === "+" || char === "?") {
      tokens.push({ type: "MODIFIER", index: i, value: str[i++] });
      continue;
    }
    if (char === "\\") {
      tokens.push({ type: "ESCAPED_CHAR", index: i++, value: str[i++] });
      continue;
    }
    if (char === "{") {
      tokens.push({ type: "OPEN", index: i, value: str[i++] });
      continue;
    }
    if (char === "}") {
      tokens.push({ type: "CLOSE", index: i, value: str[i++] });
      continue;
    }
    if (char === ":") {
      var name = "";
      var j = i + 1;
      while (j < str.length) {
        var code = str.charCodeAt(j);
        if (
          // `0-9`
          code >= 48 && code <= 57 || // `A-Z`
          code >= 65 && code <= 90 || // `a-z`
          code >= 97 && code <= 122 || // `_`
          code === 95
        ) {
          name += str[j++];
          continue;
        }
        break;
      }
      if (!name)
        throw new TypeError("Missing parameter name at ".concat(i));
      tokens.push({ type: "NAME", index: i, value: name });
      i = j;
      continue;
    }
    if (char === "(") {
      var count = 1;
      var pattern = "";
      var j = i + 1;
      if (str[j] === "?") {
        throw new TypeError('Pattern cannot start with "?" at '.concat(j));
      }
      while (j < str.length) {
        if (str[j] === "\\") {
          pattern += str[j++] + str[j++];
          continue;
        }
        if (str[j] === ")") {
          count--;
          if (count === 0) {
            j++;
            break;
          }
        } else if (str[j] === "(") {
          count++;
          if (str[j + 1] !== "?") {
            throw new TypeError("Capturing groups are not allowed at ".concat(j));
          }
        }
        pattern += str[j++];
      }
      if (count)
        throw new TypeError("Unbalanced pattern at ".concat(i));
      if (!pattern)
        throw new TypeError("Missing pattern at ".concat(i));
      tokens.push({ type: "PATTERN", index: i, value: pattern });
      i = j;
      continue;
    }
    tokens.push({ type: "CHAR", index: i, value: str[i++] });
  }
  tokens.push({ type: "END", index: i, value: "" });
  return tokens;
}
__name(lexer, "lexer");
function parse(str, options) {
  if (options === void 0) {
    options = {};
  }
  var tokens = lexer(str);
  var _a = options.prefixes, prefixes = _a === void 0 ? "./" : _a, _b = options.delimiter, delimiter = _b === void 0 ? "/#?" : _b;
  var result = [];
  var key = 0;
  var i = 0;
  var path = "";
  var tryConsume = /* @__PURE__ */ __name(function(type) {
    if (i < tokens.length && tokens[i].type === type)
      return tokens[i++].value;
  }, "tryConsume");
  var mustConsume = /* @__PURE__ */ __name(function(type) {
    var value2 = tryConsume(type);
    if (value2 !== void 0)
      return value2;
    var _a2 = tokens[i], nextType = _a2.type, index = _a2.index;
    throw new TypeError("Unexpected ".concat(nextType, " at ").concat(index, ", expected ").concat(type));
  }, "mustConsume");
  var consumeText = /* @__PURE__ */ __name(function() {
    var result2 = "";
    var value2;
    while (value2 = tryConsume("CHAR") || tryConsume("ESCAPED_CHAR")) {
      result2 += value2;
    }
    return result2;
  }, "consumeText");
  var isSafe = /* @__PURE__ */ __name(function(value2) {
    for (var _i = 0, delimiter_1 = delimiter; _i < delimiter_1.length; _i++) {
      var char2 = delimiter_1[_i];
      if (value2.indexOf(char2) > -1)
        return true;
    }
    return false;
  }, "isSafe");
  var safePattern = /* @__PURE__ */ __name(function(prefix2) {
    var prev = result[result.length - 1];
    var prevText = prefix2 || (prev && typeof prev === "string" ? prev : "");
    if (prev && !prevText) {
      throw new TypeError('Must have text between two parameters, missing text after "'.concat(prev.name, '"'));
    }
    if (!prevText || isSafe(prevText))
      return "[^".concat(escapeString(delimiter), "]+?");
    return "(?:(?!".concat(escapeString(prevText), ")[^").concat(escapeString(delimiter), "])+?");
  }, "safePattern");
  while (i < tokens.length) {
    var char = tryConsume("CHAR");
    var name = tryConsume("NAME");
    var pattern = tryConsume("PATTERN");
    if (name || pattern) {
      var prefix = char || "";
      if (prefixes.indexOf(prefix) === -1) {
        path += prefix;
        prefix = "";
      }
      if (path) {
        result.push(path);
        path = "";
      }
      result.push({
        name: name || key++,
        prefix,
        suffix: "",
        pattern: pattern || safePattern(prefix),
        modifier: tryConsume("MODIFIER") || ""
      });
      continue;
    }
    var value = char || tryConsume("ESCAPED_CHAR");
    if (value) {
      path += value;
      continue;
    }
    if (path) {
      result.push(path);
      path = "";
    }
    var open = tryConsume("OPEN");
    if (open) {
      var prefix = consumeText();
      var name_1 = tryConsume("NAME") || "";
      var pattern_1 = tryConsume("PATTERN") || "";
      var suffix = consumeText();
      mustConsume("CLOSE");
      result.push({
        name: name_1 || (pattern_1 ? key++ : ""),
        pattern: name_1 && !pattern_1 ? safePattern(prefix) : pattern_1,
        prefix,
        suffix,
        modifier: tryConsume("MODIFIER") || ""
      });
      continue;
    }
    mustConsume("END");
  }
  return result;
}
__name(parse, "parse");
function match(str, options) {
  var keys = [];
  var re = pathToRegexp(str, keys, options);
  return regexpToFunction(re, keys, options);
}
__name(match, "match");
function regexpToFunction(re, keys, options) {
  if (options === void 0) {
    options = {};
  }
  var _a = options.decode, decode = _a === void 0 ? function(x) {
    return x;
  } : _a;
  return function(pathname) {
    var m = re.exec(pathname);
    if (!m)
      return false;
    var path = m[0], index = m.index;
    var params = /* @__PURE__ */ Object.create(null);
    var _loop_1 = /* @__PURE__ */ __name(function(i2) {
      if (m[i2] === void 0)
        return "continue";
      var key = keys[i2 - 1];
      if (key.modifier === "*" || key.modifier === "+") {
        params[key.name] = m[i2].split(key.prefix + key.suffix).map(function(value) {
          return decode(value, key);
        });
      } else {
        params[key.name] = decode(m[i2], key);
      }
    }, "_loop_1");
    for (var i = 1; i < m.length; i++) {
      _loop_1(i);
    }
    return { path, index, params };
  };
}
__name(regexpToFunction, "regexpToFunction");
function escapeString(str) {
  return str.replace(/([.+*?=^!:${}()[\]|/\\])/g, "\\$1");
}
__name(escapeString, "escapeString");
function flags(options) {
  return options && options.sensitive ? "" : "i";
}
__name(flags, "flags");
function regexpToRegexp(path, keys) {
  if (!keys)
    return path;
  var groupsRegex = /\((?:\?<(.*?)>)?(?!\?)/g;
  var index = 0;
  var execResult = groupsRegex.exec(path.source);
  while (execResult) {
    keys.push({
      // Use parenthesized substring match if available, index otherwise
      name: execResult[1] || index++,
      prefix: "",
      suffix: "",
      modifier: "",
      pattern: ""
    });
    execResult = groupsRegex.exec(path.source);
  }
  return path;
}
__name(regexpToRegexp, "regexpToRegexp");
function arrayToRegexp(paths, keys, options) {
  var parts = paths.map(function(path) {
    return pathToRegexp(path, keys, options).source;
  });
  return new RegExp("(?:".concat(parts.join("|"), ")"), flags(options));
}
__name(arrayToRegexp, "arrayToRegexp");
function stringToRegexp(path, keys, options) {
  return tokensToRegexp(parse(path, options), keys, options);
}
__name(stringToRegexp, "stringToRegexp");
function tokensToRegexp(tokens, keys, options) {
  if (options === void 0) {
    options = {};
  }
  var _a = options.strict, strict = _a === void 0 ? false : _a, _b = options.start, start = _b === void 0 ? true : _b, _c = options.end, end = _c === void 0 ? true : _c, _d = options.encode, encode = _d === void 0 ? function(x) {
    return x;
  } : _d, _e = options.delimiter, delimiter = _e === void 0 ? "/#?" : _e, _f = options.endsWith, endsWith = _f === void 0 ? "" : _f;
  var endsWithRe = "[".concat(escapeString(endsWith), "]|$");
  var delimiterRe = "[".concat(escapeString(delimiter), "]");
  var route = start ? "^" : "";
  for (var _i = 0, tokens_1 = tokens; _i < tokens_1.length; _i++) {
    var token = tokens_1[_i];
    if (typeof token === "string") {
      route += escapeString(encode(token));
    } else {
      var prefix = escapeString(encode(token.prefix));
      var suffix = escapeString(encode(token.suffix));
      if (token.pattern) {
        if (keys)
          keys.push(token);
        if (prefix || suffix) {
          if (token.modifier === "+" || token.modifier === "*") {
            var mod = token.modifier === "*" ? "?" : "";
            route += "(?:".concat(prefix, "((?:").concat(token.pattern, ")(?:").concat(suffix).concat(prefix, "(?:").concat(token.pattern, "))*)").concat(suffix, ")").concat(mod);
          } else {
            route += "(?:".concat(prefix, "(").concat(token.pattern, ")").concat(suffix, ")").concat(token.modifier);
          }
        } else {
          if (token.modifier === "+" || token.modifier === "*") {
            throw new TypeError('Can not repeat "'.concat(token.name, '" without a prefix and suffix'));
          }
          route += "(".concat(token.pattern, ")").concat(token.modifier);
        }
      } else {
        route += "(?:".concat(prefix).concat(suffix, ")").concat(token.modifier);
      }
    }
  }
  if (end) {
    if (!strict)
      route += "".concat(delimiterRe, "?");
    route += !options.endsWith ? "$" : "(?=".concat(endsWithRe, ")");
  } else {
    var endToken = tokens[tokens.length - 1];
    var isEndDelimited = typeof endToken === "string" ? delimiterRe.indexOf(endToken[endToken.length - 1]) > -1 : endToken === void 0;
    if (!strict) {
      route += "(?:".concat(delimiterRe, "(?=").concat(endsWithRe, "))?");
    }
    if (!isEndDelimited) {
      route += "(?=".concat(delimiterRe, "|").concat(endsWithRe, ")");
    }
  }
  return new RegExp(route, flags(options));
}
__name(tokensToRegexp, "tokensToRegexp");
function pathToRegexp(path, keys, options) {
  if (path instanceof RegExp)
    return regexpToRegexp(path, keys);
  if (Array.isArray(path))
    return arrayToRegexp(path, keys, options);
  return stringToRegexp(path, keys, options);
}
__name(pathToRegexp, "pathToRegexp");

// ../node_modules/wrangler/templates/pages-template-worker.ts
var escapeRegex = /[.+?^${}()|[\]\\]/g;
function getOriginalPathPrefix(requestPath, normalizedPrefix) {
  let end = 0;
  for (let index = 0; index < normalizedPrefix.length; index++) {
    end++;
    if (normalizedPrefix[index] === "/") {
      while (requestPath[end] === "/") {
        end++;
      }
    }
  }
  return requestPath.slice(0, end);
}
__name(getOriginalPathPrefix, "getOriginalPathPrefix");
function* executeRequest(request) {
  const requestPath = new URL(request.url).pathname;
  const normalizedRequestPath = requestPath.replace(/\/+/g, "/");
  for (const route of [...routes].reverse()) {
    if (route.method && route.method !== request.method) {
      continue;
    }
    const routeMatcher = match(route.routePath.replace(escapeRegex, "\\$&"), {
      end: false
    });
    const mountMatcher = match(route.mountPath.replace(escapeRegex, "\\$&"), {
      end: false
    });
    const matchResult = routeMatcher(requestPath) || routeMatcher(normalizedRequestPath);
    const originalMountMatch = mountMatcher(requestPath);
    const mountMatchResult = originalMountMatch || mountMatcher(normalizedRequestPath);
    if (matchResult && mountMatchResult) {
      const path = originalMountMatch ? originalMountMatch.path : getOriginalPathPrefix(requestPath, mountMatchResult.path);
      for (const handler of route.middlewares.flat()) {
        yield {
          handler,
          params: matchResult.params,
          path
        };
      }
    }
  }
  for (const route of routes) {
    if (route.method && route.method !== request.method) {
      continue;
    }
    const routeMatcher = match(route.routePath.replace(escapeRegex, "\\$&"), {
      end: true
    });
    const mountMatcher = match(route.mountPath.replace(escapeRegex, "\\$&"), {
      end: false
    });
    const matchResult = routeMatcher(requestPath);
    const mountMatchResult = mountMatcher(requestPath);
    if (matchResult && mountMatchResult && route.modules.length) {
      for (const handler of route.modules.flat()) {
        yield {
          handler,
          params: matchResult.params,
          path: matchResult.path
        };
      }
      break;
    }
  }
}
__name(executeRequest, "executeRequest");
var pages_template_worker_default = {
  async fetch(originalRequest, env, workerContext) {
    let request = originalRequest;
    const handlerIterator = executeRequest(request);
    let data = {};
    let isFailOpen = false;
    const next = /* @__PURE__ */ __name(async (input, init) => {
      if (input !== void 0) {
        let url = input;
        if (typeof input === "string") {
          url = new URL(input, request.url).toString();
        }
        request = new Request(url, init);
      }
      const result = handlerIterator.next();
      if (result.done === false) {
        const { handler, params, path } = result.value;
        const context = {
          request: new Request(request.clone()),
          functionPath: path,
          next,
          params,
          get data() {
            return data;
          },
          set data(value) {
            if (typeof value !== "object" || value === null) {
              throw new Error("context.data must be an object");
            }
            data = value;
          },
          env,
          waitUntil: workerContext.waitUntil.bind(workerContext),
          passThroughOnException: /* @__PURE__ */ __name(() => {
            isFailOpen = true;
          }, "passThroughOnException")
        };
        const response = await handler(context);
        if (!(response instanceof Response)) {
          throw new Error("Your Pages function should return a Response");
        }
        return cloneResponse(response);
      } else if ("ASSETS") {
        const response = await env["ASSETS"].fetch(request);
        return cloneResponse(response);
      } else {
        const response = await fetch(request);
        return cloneResponse(response);
      }
    }, "next");
    try {
      return await next();
    } catch (error) {
      if (isFailOpen) {
        const response = await env["ASSETS"].fetch(request);
        return cloneResponse(response);
      }
      throw error;
    }
  }
};
var cloneResponse = /* @__PURE__ */ __name((response) => (
  // https://fetch.spec.whatwg.org/#null-body-status
  new Response(
    [101, 204, 205, 304].includes(response.status) ? null : response.body,
    response
  )
), "cloneResponse");
export {
  pages_template_worker_default as default
};
